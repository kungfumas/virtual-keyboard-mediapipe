Aim of this Project was to use mouse and keyboard using hand testures & webcam with the help of specific color range.
I have implemented mostly all useful keys in keyboard and mouse drag and drop and moving feature using python.

Tools and technologies used: Numpy,OpenCV,Masking,Contour Detection,PyAutoGUI,Pynput,json

Demo : https://www.youtube.com/watch?v=f2_GxtW-_0U&feature=youtu.be
